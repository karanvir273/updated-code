<?php
function getDB() {
    $host = 'localhost';
    $dbname = 'digital_media_collection';
    $user = 'root';
    $pass = '';

    // Create a new MySQLi instance
    $conn = new mysqli($host, $user, $pass, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die('Connect Error (' . $conn->connect_errno . ') ' . $conn->connect_error);
    }

    return $conn;
}
?>
