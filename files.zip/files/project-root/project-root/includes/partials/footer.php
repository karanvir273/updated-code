</main>
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; <?php echo date('Y'); ?> Digital Media Collection. All rights reserved.</p>
    </footer>
</body>
</html>
