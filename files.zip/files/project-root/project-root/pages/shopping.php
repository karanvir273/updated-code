<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping - Digital Media Collection</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff9e6; /* Light yellow background */
            color: #333;
            font-family: Arial, sans-serif;
        }

        .shopping-page {
            padding: 60px 0;
        }

        .card {
            margin-bottom: 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }

        .card-img-top {
            height: 180px;
            object-fit: cover;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
        }

        .card-text {
            font-size: 1rem;
            color: #555;
        }

        .card-footer {
            background-color: #f8f9fa;
            border-top: 1px solid #ddd;
            padding: 10px;
        }
    </style>
</head>

<body>
    <?php include '../includes/partials/header.php'; ?>

    <div class="shopping-page">
        <div class="container">
            <h1 class="text-center mb-4">Our Products</h1>
            <div class="row">

                <!-- Product 1 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Premium+Yoga+Mat" class="card-img-top" alt="Premium Yoga Mat">
                        <div class="card-body">
                            <h5 class="card-title">Premium Yoga Mat</h5>
                            <p class="card-text">Our Premium Yoga Mat is designed for ultimate comfort and stability. Made from high-density, eco-friendly materials, this mat provides a non-slip surface and excellent cushioning to support your yoga practice.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $45.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 2 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Adjustable+Dumbbells" class="card-img-top" alt="Adjustable Dumbbells">
                        <div class="card-body">
                            <h5 class="card-title">Adjustable Dumbbells</h5>
                            <p class="card-text">These Adjustable Dumbbells are perfect for a versatile home workout. Easily adjust the weight from 5 lbs to 52.5 lbs with a simple dial mechanism, making them ideal for both beginners and advanced users.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $199.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 3 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Resistance+Bands+Set" class="card-img-top" alt="Resistance Bands Set">
                        <div class="card-body">
                            <h5 class="card-title">Resistance Bands Set</h5>
                            <p class="card-text">Enhance your workouts with our Resistance Bands Set, which includes five different resistance levels to accommodate various exercises. These bands are made from high-quality latex, ensuring durability and elasticity.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $29.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 4 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Protein+Powder" class="card-img-top" alt="High-Performance Protein Powder">
                        <div class="card-body">
                            <h5 class="card-title">High-Performance Protein Powder</h5>
                            <p class="card-text">Fuel your workouts with our High-Performance Protein Powder. Formulated with 24g of protein per serving, it supports muscle recovery and growth. Available in delicious chocolate and vanilla flavors.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $39.99 (2 lb tub)</p>
                        </div>
                    </div>
                </div>

                <!-- Product 5 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Stainless+Steel+Water+Bottle" class="card-img-top" alt="Stainless Steel Water Bottle">
                        <div class="card-body">
                            <h5 class="card-title">Stainless Steel Water Bottle</h5>
                            <p class="card-text">Stay hydrated with our Stainless Steel Water Bottle. This 750ml bottle keeps your drinks cold for up to 24 hours or hot for up to 12 hours, making it perfect for workouts and daily use.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $19.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 6 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Gym+Gloves" class="card-img-top" alt="Gym Gloves">
                        <div class="card-body">
                            <h5 class="card-title">Gym Gloves</h5>
                            <p class="card-text">Protect your hands and enhance your grip with our durable Gym Gloves. These gloves are made with breathable material and padded palms for maximum comfort during weight lifting.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $14.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 7 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Foam+Roller" class="card-img-top" alt="Foam Roller">
                        <div class="card-body">
                            <h5 class="card-title">Foam Roller</h5>
                            <p class="card-text">Aid your recovery with our high-density Foam Roller. Perfect for self-myofascial release, this roller helps to reduce muscle tightness, improve mobility, and increase blood flow.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $24.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 8 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Smart+Fitness+Watch" class="card-img-top" alt="Smart Fitness Watch">
                        <div class="card-body">
                            <h5 class="card-title">Smart Fitness Watch</h5>
                            <p class="card-text">Track your fitness progress with our Smart Fitness Watch. Featuring heart rate monitoring, step tracking, and sleep analysis, this watch helps you stay on top of your health goals.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $59.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 9 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Treadmill" class="card-img-top" alt="Treadmill">
                        <div class="card-body">
                            <h5 class="card-title">Treadmill</h5>
                            <p class="card-text">Experience a professional-grade workout at home with our high-performance Treadmill. Featuring multiple speed settings, incline options, and a built-in display for tracking your progress, this treadmill is perfect for all fitness levels.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $799.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 10 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Exercise+Bike" class="card-img-top" alt="Exercise Bike">
                        <div class="card-body">
                            <h5 class="card-title">Exercise Bike</h5>
                            <p class="card-text">Our Exercise Bike offers a low-impact cardiovascular workout. It features adjustable resistance levels, a comfortable seat, and a digital monitor to keep track of your workout stats.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $299.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 11 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Kettlebell+Set" class="card-img-top" alt="Kettlebell Set">
                        <div class="card-body">
                            <h5 class="card-title">Kettlebell Set</h5>
                            <p class="card-text">Build strength and endurance with our Kettlebell Set. Each kettlebell is designed with a wide, comfortable handle for a secure grip, and is color-coded for easy weight identification.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $89.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 12 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Ab+Roller+Wheel" class="card-img-top" alt="Ab Roller Wheel">
                        <div class="card-body">
                            <h5 class="card-title">Ab Roller Wheel</h5>
                            <p class="card-text">Strengthen your core with our Ab Roller Wheel. This simple yet effective tool targets your abs, shoulders, and back muscles, providing a challenging and efficient workout.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $19.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 13 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Jump+Rope" class="card-img-top" alt="Jump Rope">
                        <div class="card-body">
                            <h5 class="card-title">Jump Rope</h5>
                            <p class="card-text">Improve your cardiovascular health and coordination with our high-speed Jump Rope. Adjustable length and ergonomic handles make this jump rope perfect for all fitness levels.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $14.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 14 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Medicine+Ball" class="card-img-top" alt="Medicine Ball">
                        <div class="card-body">
                            <h5 class="card-title">Medicine Ball</h5>
                            <p class="card-text">Enhance your strength and conditioning routines with our versatile Medicine Ball. Ideal for a wide range of exercises, including core work, plyometrics, and balance training.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: Starting at $29.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 15 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Weightlifting+Belt" class="card-img-top" alt="Weightlifting Belt">
                        <div class="card-body">
                            <h5 class="card-title">Weightlifting Belt</h5>
                            <p class="card-text">Support your lower back during heavy lifts with our durable Weightlifting Belt. Made from high-quality leather, this belt provides the stability and support needed for safe and effective lifting.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $49.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 16 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Pull-Up+Bar" class="card-img-top" alt="Pull-Up Bar">
                        <div class="card-body">
                            <h5 class="card-title">Pull-Up Bar</h5>
                            <p class="card-text">Install our versatile Pull-Up Bar in your home for a complete upper body workout. This bar is easy to install and can be used for pull-ups, chin-ups, and other bodyweight exercises.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $39.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 17 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Gym+Bag" class="card-img-top" alt="Gym Bag">
                        <div class="card-body">
                            <h5 class="card-title">Gym Bag</h5>
                            <p class="card-text">Carry all your workout essentials in style with our durable and spacious Gym Bag. Featuring multiple compartments, this bag keeps your gear organized and easily accessible.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $34.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 18 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Massage+Gun" class="card-img-top" alt="Massage Gun">
                        <div class="card-body">
                            <h5 class="card-title">Massage Gun</h5>
                            <p class="card-text">Accelerate muscle recovery with our high-performance Massage Gun. This device offers deep tissue massage with adjustable speeds and interchangeable heads to target specific muscle groups.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $129.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 19 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Fitness+Tracker" class="card-img-top" alt="Fitness Tracker">
                        <div class="card-body">
                            <h5 class="card-title">Fitness Tracker</h5>
                            <p class="card-text">Monitor your health and fitness progress with our advanced Fitness Tracker. Features include heart rate monitoring, sleep tracking, and step counting, all displayed on an easy-to-read screen.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $49.99</p>
                        </div>
                    </div>
                </div>

                <!-- Product 20 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x180?text=Foam+Plyo+Box" class="card-img-top" alt="Foam Plyo Box">
                        <div class="card-body">
                            <h5 class="card-title">Foam Plyo Box</h5>
                            <p class="card-text">Improve your explosive power and agility with our Foam Plyo Box. Made with high-density foam, this box provides a safe and stable platform for plyometric exercises.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $99.99</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php include '../includes/partials/footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
