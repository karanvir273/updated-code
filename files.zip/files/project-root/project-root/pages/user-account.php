<?php
session_start();
include '../includes/db.php'; // Adjust the path if necessary

// Get the database connection
$conn = getDB();

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Prepare the SQL statement
    $stmt = $conn->prepare('SELECT username, email FROM users WHERE id = ?');

    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param('i', $userId);

    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }

    // Bind result variables
    $stmt->store_result();
    $stmt->bind_result($username, $email);

    // Fetch the results
    $stmt->fetch();

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
} else {
    // User not logged in
    die('Please log in to view this page');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your custom CSS -->
</head>
<body>
        <?php include '../includes/partials/header.php'; // Ensure your header includes session handling ?>
    <div class="container mt-4">
        <h2>Dashboard</h2>
        <div class="card mb-4">
            <div class="card-body">
                <h3>Welcome, <?php echo htmlspecialchars($username); ?>!</h3>
                <p>Email: <?php echo htmlspecialchars($email); ?></p>
            </div>
        </div>

        <!-- Example of recent activity -->
        <div class="card mb-4">
            <div class="card-body">
                <h4>Recent Activity</h4>
                <ul>
                    <li>Added new favorite item</li>
                    <li>Updated profile information</li>
                    <!-- Add more recent activities here -->
                </ul>
            </div>
        </div>

        <!-- Link to Favorites page -->
        <a class="btn btn-primary" href="favorites.php">View Your Favorites</a>
</div>
    <?php include '../includes/partials/footer.php'; // Ensure your header includes session handling ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
