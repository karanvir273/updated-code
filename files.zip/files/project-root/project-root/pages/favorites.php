<?php
session_start();
include '../includes/db.php'; // Ensure the path is correct

// Get the database connection
$conn = getDB();

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Prepare the SQL statement
    $stmt = $conn->prepare('SELECT * FROM favorites WHERE user_id = ?');
    
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param('i', $userId);

    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }

    // Bind result variables
    $result = $stmt->get_result();

    // Fetch the results
    $favorites = [];
    while ($row = $result->fetch_assoc()) {
        $favorites[] = $row;
    }

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorites</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            color: #343a40;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin-top: 20px;
        }

        .card {
            margin-bottom: 20px;
        }

        .no-favorites {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include '../includes/partials/header.php'; ?>
    <div class="container">
        <h2 class="mt-4">Your Favorites</h2>
        <?php if (!empty($favorites)): ?>
            <div class="row">
                <?php foreach ($favorites as $favorite): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($favorite['item_name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($favorite['item_description']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-favorites">
                <p>You have no favorite items.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php include '../includes/partials/footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorites</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            color: #343a40;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin-top: 20px;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include '../includes/partials/header.php'; ?>
    <div class="container mt-4">
        <div class="alert alert-warning" role="alert">
            <h4 class="alert-heading">Please Log In</h4>
            <p>To view your favorite items, you need to be logged in. Please <a href="login.php" class="alert-link">log in</a> to continue.</p>
            <hr>
            <p class="mb-0">If you don't have an account, you can <a href="register.php" class="alert-link">register here</a>.</p>
        </div>
    </div>
    <?php include '../includes/partials/footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
}
?>
