<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Digital Media Collection</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background-color: #fff9e6;
            /* Light yellow background */
            color: #333;
            font-family: Arial, sans-serif;
        }


        .hero-section {
            background: url(../images/banner.jpg);
            padding: 200px 0px;
            background-size: cover;
        }

        .bg-dark {
            background-color: transparent !important;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #000;
        }

        .hero-section p {
            font-size: 1.125rem;
            line-height: 1.6;
            color: #000;
        }

        .container-fluid {
            padding: 20px;
        }

        .section-title {
            margin-top: 40px;
            margin-bottom: 20px;
            text-align: center;
        }

        .card-deck .card {
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card-deck .card:hover {
            transform: scale(1.05);
        }

        .footer {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        .hero-section .container {
            padding: 30px;
            background: rgba(255, 255, 0, 0.6);
        }
    </style>
</head>

<body>
    <?php include '../includes/partials/header.php'; ?>

    <div class="hero-section text-center">
        <div class="container">
            <h1>The Importance of Protein in Resistance Training</h1>
            <p>
                When we do resistance training, such as push-ups and lifting weights, we actually damage our muscles by causing small "tears" in them. Over time, these small tears knit together and build up stronger, which is how our muscles grow. But in order for this process to work effectively, our muscles need protein—long-chain amino acid molecules which are part of most of our body's cells.
            </p>
        </div>
    </div>

    <div class="featured-products">
        <div class="container mt-0 mb-0">
            <h2 class="text-center mb-4">Featured Products</h2>
            <div class="row">
                <!-- Featured Product 1 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x400?text=Premium+Yoga+Mat" class="card-img-top" alt="Premium Yoga Mat">
                        <div class="card-body">
                            <h5 class="card-title">Premium Yoga Mat</h5>
                            <p class="card-text">Ultimate comfort and stability with eco-friendly materials.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $45.99</p>
                        </div>
                    </div>
                </div>

                <!-- Featured Product 2 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x400?text=Adjustable+Dumbbells" class="card-img-top" alt="Adjustable Dumbbells">
                        <div class="card-body">
                            <h5 class="card-title">Adjustable Dumbbells</h5>
                            <p class="card-text">Versatile dumbbells with adjustable weights for any workout.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $199.99</p>
                        </div>
                    </div>
                </div>

                <!-- Featured Product 3 -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/600x400?text=High-Performance+Protein+Powder" class="card-img-top" alt="High-Performance Protein Powder">
                        <div class="card-body">
                            <h5 class="card-title">High-Performance Protein Powder</h5>
                            <p class="card-text">24g of protein per serving to support muscle growth and recovery.</p>
                        </div>
                        <div class="card-footer">
                            <p class="mb-0">Price: $39.99</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional sections can be added here -->

    <?php include '../includes/partials/footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>