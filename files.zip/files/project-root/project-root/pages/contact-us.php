<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Digital Media Collection</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background-color: #fff9e6;
            /* Light yellow background */
            color: #333;
            font-family: Arial, sans-serif;
        }
        
        .contact-section {
            padding: 60px 0;

            /* Yellow accent border */
        }
        
        .contact-section h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #333;
        }
        
        .contact-section p {
            font-size: 1.125rem;
            line-height: 1.6;
            color: #666;
        }
        
        
        .contact-form .form-group label {
            font-weight: bold;
        }
        
        .contact-form .form-group textarea {
            resize: none;
        }
    </style>
</head>

<body>
    <?php include '../includes/partials/header.php'; ?>

    <div class="contact-section">
        <div class="container">
            <h1>Contact Us</h1>
            <p>
                We would love to hear from you! Please fill out the form below and we will get in touch with you as soon as possible.
            </p>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <form action="process_contact.php" method="POST" class="contact-form">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/partials/footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>